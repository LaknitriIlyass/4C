public class TapparellaEletrica extends Tapparella{

    public TapparellaEletrica(int altezza, int larghezza) {
        super(altezza, larghezza);
    }

    public String telecomando_T_Eletrica(boolean bottone){
        if(bottone){
            this.setTapparella(0);
            return "la tapparella è salita tutta";
        }
        else{
            this.setTapparella(this.getAltezzaFinestra());
            return "la tapprella è scesa tutta";
        }
    }
    
}