public class Main{
    public static void main(String[] args) {
        Tapparella t1=new Tapparella(10,5);
        TapparellaEletrica t1e=new TapparellaEletrica(20,10);

        System.out.println(t1.AlzareTapparella(5));
        System.out.println(t1.ScendereTapparella(5));
        System.out.println(t1.ScendereTapparella(3));
        System.out.println(t1.ScendereTapparella(3));
        System.out.println(t1.AlzareTapparella(10));
        System.out.println(t1.ScendereTapparella(5));
        System.out.println(t1.ScendereTapparella(3));

        System.out.println(t1e.telecomando_T_Eletrica(true));
        System.out.println(t1e.telecomando_T_Eletrica(false));
    }
}