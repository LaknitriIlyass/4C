#include <stdio.h>
#include <stdlib.h>

int main(void){

    int matrice[6][8];
    int i=0;
    int j=0;
    int somma=0;
    int studente =0;
    double media_s=0;
    double media_p[7];

    for(i=0; i<6; i++){
        printf("studente %d",studente=studente+1);
        for(j=0; j<7; j++){
            printf("\ninserisci voto: ");
            scanf("%d",&matrice[i][j]);
        }
    }

    for(i=0; i<6; i++){
        somma=0;
        for(j=0; j<7; j++){
            somma=somma+matrice[i][j];
        }
        media_s = (double)somma/7;
        matrice[i][7]=media_s;
    }


    for(j=0; j<7; j++){
        somma=0;
        for(i=0; i<6; i++){
            somma=somma+matrice[i][j]; 
        }
        media_p[j]=(double)somma / 6;
    }

    for(i=0; i<7; i++){
        matrice[6][i]=media_p[i];
    }

    for(int x=0; x<7; x++){
        for(int y=0; y<8; y++){
            printf("%f ", matrice[x][y]);  
        }
        printf("\n");
    }


    return 0;
}