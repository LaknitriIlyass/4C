public class Tapparella {
    private int AltezzaFinestra;
    private int LarghezzaFinestra;
    private int tapparella;

    public Tapparella(int altezza, int larghezza){
        this.AltezzaFinestra=altezza;
        this.LarghezzaFinestra=larghezza;
        this.tapparella=0;
    }
    
    public int getAltezzaFinestra() {
        return AltezzaFinestra;
    }

    public void setAltezzaFinestra(int altezzaFinestra) {
        this.AltezzaFinestra = altezzaFinestra;
    }

    public int getLarghezzaFinestra() {
        return LarghezzaFinestra;
    }

    public void setLarghezzaFinestra(int larghezzaFinestra) {
        this.LarghezzaFinestra = larghezzaFinestra;
    }
    
    public int getTapparella() {
        return tapparella;
    }

    public void setTapparella(int tapparella) {
        this.tapparella = tapparella;
    }

    public String ScendereTapparella(int numero){
        if(numero>0){
            this.tapparella=this.tapparella+numero;
            if(this.tapparella<this.AltezzaFinestra ){
                return "la tapparella è scesa: "+this.tapparella;
            }
            else{
                this.tapparella=this.AltezzaFinestra;
                return "la tapprella è scesa tutta";
            }
        }
        else{
            return "inserisci numero maggiore di zero";
        }
    }

    public String AlzareTapparella(int numero){
        if(numero>0){
            this.tapparella=this.tapparella-numero;
            if(this.tapparella>0){
                return "la tapparella è salita:"+this.tapparella;
            }
            else{
                this.tapparella=0;
                return "la tapparella è salita tutta";
            }
        }
        else{
            return "inserisci numero maggiore di zero";
        }
    }
}

